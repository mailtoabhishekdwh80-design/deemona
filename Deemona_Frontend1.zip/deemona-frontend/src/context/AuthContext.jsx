import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { Auth } from '../api/index.js';

const AuthCtx = createContext(null);

export function AuthProvider({ children }) {
  const [user,    setUser]    = useState(null);
  const [loading, setLoading] = useState(true);

  // Boot: restore session from localStorage
  useEffect(() => {
    const token = localStorage.getItem('access_token');
    if (token) {
      Auth.me()
        .then(d => setUser(d.data))
        .catch(() => { localStorage.removeItem('access_token'); localStorage.removeItem('refresh_token'); })
        .finally(() => setLoading(false));
    } else {
      setLoading(false);
    }
  }, []);

  const login = useCallback(async (email, password, totpCode) => {
    const d = await Auth.login({ email, password, ...(totpCode && { totpCode }) });
    if (d.data?.requires2FA) return { requires2FA: true };
    localStorage.setItem('access_token',  d.data.accessToken);
    localStorage.setItem('refresh_token', d.data.refreshToken);
    setUser(d.data.customer || d.data.admin);
    return d.data;
  }, []);

  const register = useCallback(async body => {
    const d = await Auth.register(body);
    localStorage.setItem('access_token',  d.data.accessToken);
    localStorage.setItem('refresh_token', d.data.refreshToken);
    setUser(d.data.customer);
    return d.data;
  }, []);

  const logout = useCallback(async () => {
    const refresh = localStorage.getItem('refresh_token');
    try { await Auth.logout({ refreshToken: refresh }); } catch {}
    localStorage.removeItem('access_token');
    localStorage.removeItem('refresh_token');
    setUser(null);
  }, []);

  const updateUser = useCallback(data => setUser(prev => ({ ...prev, ...data })), []);

  const isAdmin  = user?.role && ['admin','super_admin','manager','support'].includes(user.role);
  const isAuthed = !!user;

  return (
    <AuthCtx.Provider value={{ user, loading, isAuthed, isAdmin, login, register, logout, updateUser }}>
      {children}
    </AuthCtx.Provider>
  );
}

export const useAuth = () => useContext(AuthCtx);
