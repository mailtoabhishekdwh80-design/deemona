import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Products, Categories, Discounts } from '../api/index.js';
import ProductCard from '../components/ProductCard.jsx';
import Spinner from '../components/Spinner.jsx';

const HERO_CATEGORIES = [
  { name: 'Electronics',      icon: '⚡', color: '#1e3a5f', light: '#dbeafe' },
  { name: 'Clothing',         icon: '👕', color: '#3b1f5e', light: '#ede9fe' },
  { name: 'Books',            icon: '📚', color: '#1a3a2e', light: '#d1fae5' },
  { name: 'Home Decor',       icon: '🪴', color: '#3d2b0e', light: '#fef3c7' },
  { name: 'Home Appliances',  icon: '🏠', color: '#1f3040', light: '#e0f2fe' },
  { name: 'Gym Accessories',  icon: '💪', color: '#1a1a2e', light: '#e0e7ff' },
  { name: 'Sports',           icon: '⚽', color: '#0e2a1a', light: '#dcfce7' },
  { name: 'Medicines',        icon: '💊', color: '#2a0e1a', light: '#fce7f3' },
];

const BANNERS = [
  { title: 'New Arrivals', sub: 'Electronics 2025', cta: 'Shop Now', cat: 'Electronics', bg: 'linear-gradient(135deg,#0a0f1e 0%,#1a2540 100%)', accent: '#c9973a' },
  { title: 'Summer Fashion', sub: 'Up to 60% Off', cta: 'Explore', cat: 'Clothing', bg: 'linear-gradient(135deg,#1a0a2e 0%,#2d1b69 100%)', accent: '#a78bfa' },
  { title: 'Fitness Deals', sub: 'Gym & Sports Gear', cta: 'Get Fit', cat: 'Sports', bg: 'linear-gradient(135deg,#052e16 0%,#14532d 100%)', accent: '#4ade80' },
];

export default function Home() {
  const navigate = useNavigate();
  const [featured,   setFeatured]   = useState([]);
  const [newArrivals,setNewArrivals]= useState([]);
  const [coupons,    setCoupons]    = useState([]);
  const [bannerIdx,  setBannerIdx]  = useState(0);
  const [loading,    setLoading]    = useState(true);

  useEffect(() => {
    Promise.all([
      Products.list({ featured: true, limit: 8 }),
      Products.list({ sort: 'newest', limit: 8 }),
      Discounts.active(),
    ]).then(([feat, newest, disc]) => {
      setFeatured(feat.data?.products || []);
      setNewArrivals(newest.data?.products || []);
      setCoupons(disc.data?.slice(0, 3) || []);
    }).catch(() => {}).finally(() => setLoading(false));
  }, []);

  // Auto-rotate banner
  useEffect(() => {
    const t = setInterval(() => setBannerIdx(i => (i + 1) % BANNERS.length), 5000);
    return () => clearInterval(t);
  }, []);

  const banner = BANNERS[bannerIdx];

  return (
    <div className="page-enter">
      {/* ── Hero Banner ────────────────────────────────── */}
      <div style={{ background: banner.bg, minHeight: 480, display: 'flex', alignItems: 'center', position: 'relative', overflow: 'hidden', transition: 'background 1s ease' }}>
        {/* Decorative circles */}
        <div style={{ position: 'absolute', right: -80, top: -80, width: 500, height: 500, borderRadius: '50%', background: `${banner.accent}15`, pointerEvents: 'none' }}/>
        <div style={{ position: 'absolute', right: 80, bottom: -100, width: 300, height: 300, borderRadius: '50%', background: `${banner.accent}10`, pointerEvents: 'none' }}/>
        <div className="container" style={{ position: 'relative', zIndex: 1 }}>
          <div style={{ maxWidth: 560 }}>
            <div style={{ fontSize: 12, fontWeight: 700, letterSpacing: '.16em', color: banner.accent, marginBottom: 16, textTransform: 'uppercase' }}>Deemona Exclusive</div>
            <h1 style={{ fontFamily: 'var(--display)', fontSize: 'clamp(44px,5vw,72px)', fontWeight: 700, color: '#fff', lineHeight: 1.05, marginBottom: 12 }}>
              {banner.title}<br/><em style={{ fontStyle: 'italic', color: banner.accent }}>{banner.sub}</em>
            </h1>
            <p style={{ fontSize: 16, color: 'rgba(255,255,255,.65)', marginBottom: 32, maxWidth: 400 }}>
              Curated collection with exclusive deals, premium quality and next-day delivery.
            </p>
            <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
              <button className="btn btn-gold btn-lg" onClick={() => navigate(`/shop/${banner.cat}`)}>{banner.cta}</button>
              <button className="btn btn-outline btn-lg" style={{ borderColor: 'rgba(255,255,255,.3)', color: '#fff' }} onClick={() => navigate('/shop')}>All Products</button>
            </div>
          </div>
        </div>

        {/* Dot indicators */}
        <div style={{ position: 'absolute', bottom: 24, left: '50%', transform: 'translateX(-50%)', display: 'flex', gap: 8 }}>
          {BANNERS.map((_, i) => (
            <button key={i} onClick={() => setBannerIdx(i)} style={{ width: i === bannerIdx ? 24 : 8, height: 8, borderRadius: 4, background: i === bannerIdx ? banner.accent : 'rgba(255,255,255,.3)', border: 'none', cursor: 'pointer', transition: 'all .3s' }}/>
          ))}
        </div>
      </div>

      {/* ── Offer ticker ─────────────────────────────── */}
      {coupons.length > 0 && (
        <div style={{ background: 'var(--nav-strip)', padding: '12px 0', overflow: 'hidden' }}>
          <div style={{ display: 'flex', gap: 48, animation: 'marquee 18s linear infinite', whiteSpace: 'nowrap' }}>
            {[...coupons, ...coupons].map((c, i) => (
              <span key={i} style={{ fontSize: 12, fontWeight: 700, color: 'rgba(255,255,255,.8)', letterSpacing: '.08em' }}>
                🏷 <span style={{ color: 'var(--teal)' }}>{c.Code}</span> — {c.Description}
              </span>
            ))}
          </div>
          <style>{`@keyframes marquee{from{transform:translateX(0)}to{transform:translateX(-50%)}}`}</style>
        </div>
      )}

      {/* ── Category grid ────────────────────────────── */}
      <section className="section" style={{ background: 'var(--cream)' }}>
        <div className="container">
          <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: 28 }}>
            <h2 className="section-title">Shop by <em>Category</em></h2>
            <Link to="/shop" style={{ fontSize: 13, fontWeight: 600, color: 'var(--teal)' }}>View All →</Link>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16 }}>
            {HERO_CATEGORIES.map(c => (
              <Link key={c.name} to={`/shop/${encodeURIComponent(c.name)}`} style={{ textDecoration: 'none' }}>
                <div style={{
                  background: 'var(--white)', border: '1px solid var(--border)', borderRadius: 14,
                  padding: '28px 20px', textAlign: 'center',
                  transition: 'all .2s', cursor: 'pointer',
                }}
                onMouseEnter={e => { e.currentTarget.style.transform='translateY(-4px)'; e.currentTarget.style.boxShadow='var(--sh2)'; e.currentTarget.style.borderColor='var(--teal)'; }}
                onMouseLeave={e => { e.currentTarget.style.transform='none'; e.currentTarget.style.boxShadow='none'; e.currentTarget.style.borderColor='var(--border)'; }}
                >
                  <div style={{ fontSize: 36, marginBottom: 10 }}>{c.icon}</div>
                  <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--ink)' }}>{c.name}</div>
                </div>
              </Link>
            ))}
          </div>
          <style>{`@media(max-width:768px){.cat-grid{grid-template-columns:repeat(4,1fr)!important;gap:10px!important}}`}</style>
        </div>
      </section>

      {/* ── Featured Products ─────────────────────────── */}
      <section className="section" style={{ background: 'var(--white)' }}>
        <div className="container">
          <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: 28 }}>
            <h2 className="section-title">Featured <em>Products</em></h2>
            <Link to="/shop?featured=true" style={{ fontSize: 13, fontWeight: 600, color: 'var(--teal)' }}>See All →</Link>
          </div>
          {loading ? <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 20 }}>
            {[...Array(4)].map((_,i) => <div key={i} className="skeleton" style={{ height: 360, borderRadius: 12 }}/>)}
          </div> : (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 20 }}>
              {featured.slice(0,8).map(p => <ProductCard key={p.ProductID} product={p}/>)}
            </div>
          )}
        </div>
      </section>

      {/* ── Value props ───────────────────────────────── */}
      <section style={{ background: 'var(--nav)', padding: '48px 0' }}>
        <div className="container">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 24 }}>
            {[
              { icon: '🚀', title: 'Fast Delivery', sub: 'Metro: 3 days · Standard: 5 days' },
              { icon: '🔒', title: 'Secure Payments', sub: 'Razorpay · UPI · Cards · COD' },
              { icon: '↩️', title: '10-Day Returns', sub: 'Hassle-free return policy' },
              { icon: '🎁', title: 'Loyalty Points', sub: '1 point per ₹100 spent' },
            ].map(v => (
              <div key={v.title} style={{ textAlign: 'center', padding: '20px 12px' }}>
                <div style={{ fontSize: 32, marginBottom: 10 }}>{v.icon}</div>
                <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--white)', marginBottom: 4 }}>{v.title}</div>
                <div style={{ fontSize: 12, color: 'rgba(255,255,255,.5)' }}>{v.sub}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── New Arrivals ──────────────────────────────── */}
      <section className="section" style={{ background: 'var(--cream)' }}>
        <div className="container">
          <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: 28 }}>
            <h2 className="section-title">New <em>Arrivals</em></h2>
            <Link to="/shop?sort=newest" style={{ fontSize: 13, fontWeight: 600, color: 'var(--teal)' }}>View All →</Link>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 20 }}>
            {loading ? [...Array(4)].map((_,i) => <div key={i} className="skeleton" style={{ height: 360, borderRadius: 12 }}/>)
              : newArrivals.slice(0,8).map(p => <ProductCard key={p.ProductID} product={p}/>)}
          </div>
        </div>
      </section>
    </div>
  );
}
