import React, { useEffect, useState } from 'react';
import { Admin, Orders as OrdersAPI } from '../../api/index.js';
import Spinner from '../../components/Spinner.jsx';

function StatCard({ label, value, sub, icon, color = 'var(--gold)' }) {
  return (
    <div style={{ background: 'var(--white)', border: '1px solid var(--border)', borderRadius: 14, padding: '20px 24px', display: 'flex', alignItems: 'flex-start', gap: 16 }}>
      <div style={{ width: 48, height: 48, borderRadius: 12, background: `${color}18`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22, flexShrink: 0 }}>{icon}</div>
      <div>
        <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: '.08em', marginBottom: 4 }}>{label}</div>
        <div style={{ fontSize: 26, fontWeight: 800, fontFamily: 'var(--display)', color: 'var(--ink)', lineHeight: 1 }}>{value}</div>
        {sub && <div style={{ fontSize: 12, color: 'var(--muted)', marginTop: 4 }}>{sub}</div>}
      </div>
    </div>
  );
}

const STATUS_COLORS = {
  pending: '#f59e0b', confirmed: '#3b82f6', processing: '#8b5cf6',
  shipped: '#06b6d4', delivered: '#10b981', cancelled: '#ef4444',
};

export default function Dashboard() {
  const [dash,    setDash]    = useState(null);
  const [orders,  setOrders]  = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      Admin.dashboard(),
      OrdersAPI.adminList({ limit: 8, sort: 'newest' }),
    ]).then(([d, o]) => {
      setDash(d.data || d);
      setOrders(o.data?.orders || []);
    }).catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <Spinner full />;

  const s = dash?.summary || {};
  const topProducts   = dash?.topProducts   || [];
  const recentOrders  = orders;

  return (
    <div className="page-enter">
      <div style={{ marginBottom: 28 }}>
        <h1 style={{ fontFamily: 'var(--display)', fontSize: 32, fontWeight: 700, marginBottom: 4 }}>Dashboard</h1>
        <p style={{ fontSize: 14, color: 'var(--muted)' }}>Welcome back. Here's what's happening today.</p>
      </div>

      {/* ── KPI row ──────────────────────────────────── */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 16, marginBottom: 28 }}>
        <StatCard label="Total Revenue"    value={`₹${((s.TotalRevenue || s.totalRevenue || 0)/1000).toFixed(1)}K`} sub="All time" icon="💰" color="#c9973a"/>
        <StatCard label="Total Orders"     value={(s.TotalOrders || s.totalOrders || 0).toLocaleString('en-IN')} sub={`${s.PendingOrders || 0} pending`} icon="📦" color="#3b82f6"/>
        <StatCard label="Customers"        value={(s.TotalCustomers || s.totalCustomers || 0).toLocaleString('en-IN')} sub="Registered accounts" icon="👤" color="#8b5cf6"/>
        <StatCard label="Avg. Order Value" value={`₹${Math.round(s.AvgOrderValue || s.avgOrderValue || 0).toLocaleString('en-IN')}`} sub="Per order" icon="📈" color="#10b981"/>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 340px', gap: 24, marginBottom: 28 }}>

        {/* ── Recent orders ─────────────────────────── */}
        <div style={{ background: 'var(--white)', border: '1px solid var(--border)', borderRadius: 16, overflow: 'hidden' }}>
          <div style={{ padding: '18px 24px', borderBottom: '1px solid var(--border)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <h3 style={{ fontSize: 15, fontWeight: 700 }}>Recent Orders</h3>
            <a href="/admin/orders" style={{ fontSize: 12, color: 'var(--gold)', fontWeight: 600 }}>View all →</a>
          </div>
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr style={{ background: 'var(--cream)' }}>
                  {['Order', 'Customer', 'Amount', 'Status', 'Date'].map(h => (
                    <th key={h} style={{ padding: '10px 16px', fontSize: 11, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.08em', color: 'var(--muted)', textAlign: 'left', borderBottom: '1px solid var(--border)', whiteSpace: 'nowrap' }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {recentOrders.length === 0 ? (
                  <tr><td colSpan={5} style={{ padding: '32px 16px', textAlign: 'center', color: 'var(--muted)', fontSize: 14 }}>No orders yet</td></tr>
                ) : recentOrders.map((o, i) => (
                  <tr key={o.OrderID} style={{ borderBottom: '1px solid var(--border)', background: i % 2 ? 'var(--cream)' : 'var(--white)' }}>
                    <td style={{ padding: '12px 16px', fontSize: 13, fontWeight: 700, color: 'var(--gold)' }}>#{o.OrderID}</td>
                    <td style={{ padding: '12px 16px', fontSize: 13 }}>{o.CustomerName || o.FirstName + ' ' + o.LastName}</td>
                    <td style={{ padding: '12px 16px', fontSize: 13, fontWeight: 600 }}>₹{o.TotalAmount?.toLocaleString('en-IN')}</td>
                    <td style={{ padding: '12px 16px' }}>
                      <span style={{ padding: '3px 10px', borderRadius: 100, fontSize: 11, fontWeight: 700, background: `${STATUS_COLORS[o.Status] || '#888'}20`, color: STATUS_COLORS[o.Status] || '#888', textTransform: 'capitalize' }}>{o.Status}</span>
                    </td>
                    <td style={{ padding: '12px 16px', fontSize: 12, color: 'var(--muted)' }}>{new Date(o.OrderDate).toLocaleDateString('en-IN', { day: '2-digit', month: 'short' })}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* ── Order status breakdown ─────────────────── */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          <div style={{ background: 'var(--white)', border: '1px solid var(--border)', borderRadius: 16, padding: 20 }}>
            <h3 style={{ fontSize: 15, fontWeight: 700, marginBottom: 16 }}>Order Status</h3>
            {Object.entries(dash?.ordersByStatus || {}).map(([status, count]) => {
              const total = Object.values(dash?.ordersByStatus || {}).reduce((a, b) => a + b, 0) || 1;
              const pct   = Math.round((count / total) * 100);
              return (
                <div key={status} style={{ marginBottom: 12 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, marginBottom: 4 }}>
                    <span style={{ textTransform: 'capitalize', fontWeight: 500 }}>{status}</span>
                    <span style={{ color: 'var(--muted)', fontWeight: 600 }}>{count} ({pct}%)</span>
                  </div>
                  <div style={{ height: 6, background: 'var(--cream)', borderRadius: 4, overflow: 'hidden' }}>
                    <div style={{ height: '100%', width: `${pct}%`, background: STATUS_COLORS[status] || 'var(--gold)', borderRadius: 4, transition: 'width .6s ease' }}/>
                  </div>
                </div>
              );
            })}
            {!dash?.ordersByStatus && <div style={{ fontSize: 13, color: 'var(--muted)', textAlign: 'center', padding: '20px 0' }}>No data available</div>}
          </div>

          <div style={{ background: 'var(--white)', border: '1px solid var(--border)', borderRadius: 16, padding: 20 }}>
            <h3 style={{ fontSize: 15, fontWeight: 700, marginBottom: 16 }}>Quick Stats</h3>
            {[
              { label: 'Low stock items',    value: s.LowStockItems    || 0, color: '#ef4444' },
              { label: 'Pending refunds',    value: s.PendingRefunds   || 0, color: '#f59e0b' },
              { label: 'Active discounts',   value: s.ActiveDiscounts  || 0, color: '#10b981' },
              { label: 'Avg. rating',        value: (s.AvgRating || 4.2).toFixed(1) + ' ★', color: '#c9973a' },
            ].map(q => (
              <div key={q.label} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid var(--border)', fontSize: 13 }}>
                <span style={{ color: 'var(--sub)' }}>{q.label}</span>
                <span style={{ fontWeight: 700, color: q.color }}>{q.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ── Top products ─────────────────────────────── */}
      {topProducts.length > 0 && (
        <div style={{ background: 'var(--white)', border: '1px solid var(--border)', borderRadius: 16, overflow: 'hidden' }}>
          <div style={{ padding: '18px 24px', borderBottom: '1px solid var(--border)' }}>
            <h3 style={{ fontSize: 15, fontWeight: 700 }}>Top Products by Revenue</h3>
          </div>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: 'var(--cream)' }}>
                {['#','Product','Category','Price','Sales','Revenue'].map(h => (
                  <th key={h} style={{ padding: '10px 16px', fontSize: 11, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.08em', color: 'var(--muted)', textAlign: 'left', borderBottom: '1px solid var(--border)' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {topProducts.slice(0, 5).map((p, i) => (
                <tr key={p.ProductID} style={{ borderBottom: '1px solid var(--border)' }}>
                  <td style={{ padding: '12px 16px', fontSize: 13, color: 'var(--muted)' }}>{i + 1}</td>
                  <td style={{ padding: '12px 16px', fontSize: 13, fontWeight: 600, maxWidth: 240 }}>{p.Name}</td>
                  <td style={{ padding: '12px 16px', fontSize: 12, color: 'var(--muted)' }}>{p.CategoryName}</td>
                  <td style={{ padding: '12px 16px', fontSize: 13 }}>₹{p.Price?.toLocaleString('en-IN')}</td>
                  <td style={{ padding: '12px 16px', fontSize: 13 }}>{p.TotalSold || p.SalesCount || 0}</td>
                  <td style={{ padding: '12px 16px', fontSize: 13, fontWeight: 700, color: 'var(--green)' }}>₹{(p.Revenue || p.TotalRevenue || 0).toLocaleString('en-IN')}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
