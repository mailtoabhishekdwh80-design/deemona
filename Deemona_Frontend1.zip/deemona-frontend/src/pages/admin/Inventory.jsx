import React, { useEffect, useState, useCallback } from 'react';
import { Inventory } from '../../api/index.js';
import { useToast } from '../../context/ToastContext.jsx';
import Spinner from '../../components/Spinner.jsx';

export default function AdminInventory() {
  const { add: toast } = useToast();
  const [items,   setItems]   = useState([]);
  const [alerts,  setAlerts]  = useState([]);
  const [loading, setLoading] = useState(true);
  const [view,    setView]    = useState('all'); // all | alerts
  const [editing, setEditing] = useState(null);
  const [newQty,  setNewQty]  = useState('');
  const [saving,  setSaving]  = useState(false);
  const [page,    setPage]    = useState(1);
  const [total,   setTotal]   = useState(0);
  const LIMIT = 30;

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [inv, alrt] = await Promise.all([
        Inventory.list({ page, limit: LIMIT }),
        Inventory.alerts(),
      ]);
      setItems(inv.data?.inventory || inv.data || []);
      setTotal(inv.data?.pagination?.total || inv.data?.length || 0);
      setAlerts(alrt.data || []);
    } catch { toast('Failed to load inventory', 'error'); }
    finally { setLoading(false); }
  }, [page]);

  useEffect(() => { load(); }, [load]);

  const handleUpdateStock = async id => {
    if (!newQty || isNaN(parseInt(newQty))) { toast('Enter a valid quantity', 'error'); return; }
    setSaving(true);
    try {
      await Inventory.update(id, { StockQuantity: parseInt(newQty) });
      toast('Stock updated', 'success');
      setEditing(null); setNewQty('');
      load();
    } catch (e) { toast(e?.error || 'Failed to update', 'error'); }
    finally { setSaving(false); }
  };

  const displayed = view === 'alerts' ? alerts : items;

  return (
    <div className="page-enter">
      <div style={{ marginBottom: 24 }}>
        <h1 style={{ fontFamily: 'var(--display)', fontSize: 28, fontWeight: 700 }}>Inventory</h1>
        <p style={{ fontSize: 13, color: 'var(--muted)', marginTop: 2 }}>Manage stock levels and monitor low inventory alerts</p>
      </div>

      {/* Summary cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 16, marginBottom: 24 }}>
        {[
          { label: 'Total SKUs',     value: total,          color: 'var(--blue)', icon: '📦' },
          { label: 'Low Stock',      value: alerts.length,  color: 'var(--amber)', icon: '⚠️' },
          { label: 'Out of Stock',   value: items.filter(i => (i.StockQuantity || i.Quantity) <= 0).length, color: 'var(--red)', icon: '🚫' },
        ].map(c => (
          <div key={c.label} style={{ background: 'var(--white)', border: '1px solid var(--border)', borderRadius: 14, padding: '18px 20px', display: 'flex', alignItems: 'center', gap: 14 }}>
            <div style={{ fontSize: 28 }}>{c.icon}</div>
            <div>
              <div style={{ fontSize: 22, fontWeight: 800, color: c.color }}>{c.value}</div>
              <div style={{ fontSize: 12, color: 'var(--muted)', fontWeight: 600 }}>{c.label}</div>
            </div>
          </div>
        ))}
      </div>

      {/* View toggle */}
      <div style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
        {[['all','All Inventory'],['alerts','Low Stock Alerts']].map(([v, l]) => (
          <button key={v} onClick={() => setView(v)} style={{
            padding: '8px 18px', borderRadius: 100, fontSize: 13, fontWeight: 600,
            border: view === v ? 'none' : '1px solid var(--border)',
            background: view === v ? 'var(--navy)' : 'var(--white)',
            color: view === v ? 'var(--white)' : 'var(--muted)',
            cursor: 'pointer',
          }}>
            {l}{v === 'alerts' && alerts.length > 0 ? ` (${alerts.length})` : ''}
          </button>
        ))}
      </div>

      {loading ? <Spinner full /> : (
        <div style={{ background: 'var(--white)', border: '1px solid var(--border)', borderRadius: 16, overflow: 'hidden' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: 600 }}>
            <thead>
              <tr style={{ background: 'var(--cream)' }}>
                {['Product', 'SKU', 'Category', 'In Stock', 'Reorder Level', 'Status', 'Update Stock'].map(h => (
                  <th key={h} style={{ padding: '12px 16px', fontSize: 11, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.07em', color: 'var(--muted)', textAlign: 'left', borderBottom: '1px solid var(--border)', whiteSpace: 'nowrap' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {displayed.length === 0 ? (
                <tr><td colSpan={7} style={{ padding: '40px', textAlign: 'center', color: 'var(--muted)' }}>
                  {view === 'alerts' ? '✅ No low-stock alerts — all products well stocked!' : 'No inventory records'}
                </td></tr>
              ) : displayed.map((item, i) => {
                const qty    = item.StockQuantity ?? item.Quantity ?? 0;
                const reorder= item.ReorderLevel ?? item.reorderLevel ?? 10;
                const status = qty <= 0 ? 'out' : qty <= reorder ? 'low' : 'ok';
                const statusUI = {
                  ok:  { label: 'In Stock',     bg: 'var(--green-l)', color: 'var(--green)' },
                  low: { label: 'Low Stock',    bg: 'var(--amber-l)', color: 'var(--amber)' },
                  out: { label: 'Out of Stock', bg: 'var(--red-l)',   color: 'var(--red)' },
                }[status];
                const productId = item.ProductID || item.InventoryID;

                return (
                  <tr key={productId} style={{ borderBottom: '1px solid var(--border)', background: i % 2 ? 'var(--cream)' : 'var(--white)' }}>
                    <td style={{ padding: '12px 16px' }}>
                      <div style={{ fontSize: 13, fontWeight: 600, maxWidth: 200, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{item.ProductName || item.Name}</div>
                      {item.Brand && <div style={{ fontSize: 11, color: 'var(--muted)' }}>{item.Brand}</div>}
                    </td>
                    <td style={{ padding: '12px 16px', fontSize: 12, fontFamily: 'var(--mono)', color: 'var(--muted)' }}>{item.SKU || '—'}</td>
                    <td style={{ padding: '12px 16px', fontSize: 12, color: 'var(--sub)' }}>{item.CategoryName || '—'}</td>
                    <td style={{ padding: '12px 16px' }}>
                      <span style={{ fontSize: 16, fontWeight: 800, color: statusUI.color }}>{qty}</span>
                    </td>
                    <td style={{ padding: '12px 16px', fontSize: 13, color: 'var(--sub)' }}>{reorder}</td>
                    <td style={{ padding: '12px 16px' }}>
                      <span style={{ padding: '3px 10px', borderRadius: 100, fontSize: 11, fontWeight: 700, background: statusUI.bg, color: statusUI.color }}>{statusUI.label}</span>
                    </td>
                    <td style={{ padding: '12px 16px' }}>
                      {editing === productId ? (
                        <div style={{ display: 'flex', gap: 6 }}>
                          <input type="number" value={newQty} onChange={e => setNewQty(e.target.value)} className="input" style={{ width: 80, padding: '5px 8px', fontSize: 13 }} autoFocus min={0}/>
                          <button onClick={() => handleUpdateStock(productId)} disabled={saving} style={{ padding: '5px 12px', borderRadius: 6, background: 'var(--green)', color: '#fff', border: 'none', cursor: 'pointer', fontSize: 12, fontWeight: 600 }}>{saving ? '…' : '✓'}</button>
                          <button onClick={() => { setEditing(null); setNewQty(''); }} style={{ padding: '5px 10px', borderRadius: 6, background: 'var(--cream)', border: '1px solid var(--border)', cursor: 'pointer', fontSize: 12 }}>✕</button>
                        </div>
                      ) : (
                        <button onClick={() => { setEditing(productId); setNewQty(String(qty)); }} className="btn btn-outline btn-sm">Update</button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>

          {view === 'all' && Math.ceil(total / LIMIT) > 1 && (
            <div style={{ display: 'flex', justifyContent: 'center', gap: 8, padding: '16px', borderTop: '1px solid var(--border)' }}>
              <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1} className="btn btn-outline btn-sm">← Prev</button>
              <span style={{ padding: '8px 16px', fontSize: 13, color: 'var(--muted)' }}>Page {page} of {Math.ceil(total / LIMIT)}</span>
              <button onClick={() => setPage(p => p + 1)} disabled={page >= Math.ceil(total / LIMIT)} className="btn btn-outline btn-sm">Next →</button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
