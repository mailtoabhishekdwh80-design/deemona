import React from 'react';
import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext.jsx';

const NAV = [
  { to: '/admin',            icon: '◫',  label: 'Dashboard',  end: true },
  { to: '/admin/products',   icon: '📦', label: 'Products' },
  { to: '/admin/orders',     icon: '🧾', label: 'Orders' },
  { to: '/admin/customers',  icon: '👤', label: 'Customers' },
  { to: '/admin/inventory',  icon: '📊', label: 'Inventory' },
];

export default function AdminLayout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => { await logout(); navigate('/'); };

  return (
    <div style={{ display: 'flex', minHeight: 'calc(100vh - 65px)', background: 'var(--cream)' }}>
      {/* Sidebar */}
      <aside style={{ width: 220, background: 'var(--navy)', display: 'flex', flexDirection: 'column', flexShrink: 0, position: 'sticky', top: 65, height: 'calc(100vh - 65px)', overflowY: 'auto' }}>
        <div style={{ padding: '20px 16px', borderBottom: '1px solid rgba(255,255,255,.08)' }}>
          <div style={{ fontSize: 12, fontWeight: 700, letterSpacing: '.1em', color: 'var(--gold)', textTransform: 'uppercase', marginBottom: 4 }}>Admin Panel</div>
          <div style={{ fontSize: 13, color: 'rgba(255,255,255,.6)' }}>{user?.FirstName} {user?.LastName}</div>
          <div style={{ fontSize: 11, color: 'rgba(255,255,255,.3)', textTransform: 'capitalize' }}>{user?.role}</div>
        </div>

        <nav style={{ flex: 1, padding: '12px 8px' }}>
          {NAV.map(n => (
            <NavLink key={n.to} to={n.to} end={n.end} style={({ isActive }) => ({
              display: 'flex', alignItems: 'center', gap: 10, padding: '10px 12px',
              borderRadius: 8, marginBottom: 2, fontSize: 13, fontWeight: 500,
              color: isActive ? 'var(--white)' : 'rgba(255,255,255,.6)',
              background: isActive ? 'rgba(201,151,58,.15)' : 'transparent',
              borderLeft: isActive ? '2px solid var(--gold)' : '2px solid transparent',
              textDecoration: 'none', transition: 'all .15s',
            })}
            onMouseEnter={e => { if (!e.currentTarget.style.background.includes('201')) { e.currentTarget.style.background='rgba(255,255,255,.05)'; e.currentTarget.style.color='rgba(255,255,255,.9)'; }}}
            onMouseLeave={e => { if (!e.currentTarget.style.background.includes('201')) { e.currentTarget.style.background='transparent'; e.currentTarget.style.color='rgba(255,255,255,.6)'; }}}
            >
              <span style={{ fontSize: 16 }}>{n.icon}</span>
              {n.label}
            </NavLink>
          ))}
        </nav>

        <div style={{ padding: '12px 8px', borderTop: '1px solid rgba(255,255,255,.08)' }}>
          <button onClick={() => navigate('/')} style={{ width: '100%', padding: '10px 12px', borderRadius: 8, background: 'transparent', border: 'none', color: 'rgba(255,255,255,.5)', fontSize: 13, textAlign: 'left', cursor: 'pointer', marginBottom: 4 }}>← Back to Store</button>
          <button onClick={handleLogout} style={{ width: '100%', padding: '10px 12px', borderRadius: 8, background: 'transparent', border: 'none', color: 'rgba(239,68,68,.7)', fontSize: 13, textAlign: 'left', cursor: 'pointer' }}>Sign Out</button>
        </div>
      </aside>

      {/* Main content */}
      <main style={{ flex: 1, padding: '32px', overflowX: 'hidden', minWidth: 0 }}>
        <Outlet />
      </main>
    </div>
  );
}
