// ============================================================
//  Cart.jsx
// ============================================================
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useCart } from '../context/CartContext.jsx';
import { Discounts } from '../api/index.js';
import { useToast } from '../context/ToastContext.jsx';
import Spinner from '../components/Spinner.jsx';

export function CartPage() {
  const { items, summary, loading, updateItem, removeItem, clearCart } = useCart();
  const { add: toast } = useToast();
  const navigate = useNavigate();
  const [coupon, setCoupon]     = useState('');
  const [discount, setDiscount] = useState(null);
  const [validating, setVal]    = useState(false);

  const handleCoupon = async () => {
    if (!coupon.trim()) return;
    setVal(true);
    try {
      const d = await Discounts.validate({ code: coupon, orderAmount: summary.subtotal || 0 });
      setDiscount(d.data);
      toast(`Coupon applied: ${d.data.savings?.toLocaleString ? '₹' + d.data.savings.toLocaleString('en-IN') + ' off' : 'Discount applied'}`, 'success');
    } catch (e) { toast(e?.error || 'Invalid coupon code', 'error'); }
    finally { setVal(false); }
  };

  const discountAmt = discount?.discountAmount || discount?.savings || 0;
  const finalTotal  = Math.max(0, (summary.subtotal || 0) - discountAmt);

  if (loading) return <Spinner full />;

  return (
    <div className="page-enter">
      <div className="container" style={{ padding: '40px 24px' }}>
        <h1 style={{ fontFamily: 'var(--display)', fontSize: 36, fontWeight: 700, marginBottom: 32 }}>Shopping <em style={{ color: 'var(--gold)', fontStyle: 'italic' }}>Cart</em></h1>

        {items.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '80px 0' }}>
            <div style={{ fontSize: 64, marginBottom: 20 }}>🛒</div>
            <h2 style={{ fontFamily: 'var(--display)', fontSize: 28, marginBottom: 12 }}>Your cart is empty</h2>
            <p style={{ color: 'var(--muted)', marginBottom: 24 }}>Add items from our wide selection of products</p>
            <Link to="/shop" className="btn btn-gold btn-lg">Start Shopping</Link>
          </div>
        ) : (
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 360px', gap: 32, alignItems: 'start' }}>
            {/* Items */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
                <span style={{ fontSize: 14, color: 'var(--muted)' }}>{items.length} item{items.length > 1 ? 's' : ''}</span>
                <button onClick={() => clearCart()} style={{ fontSize: 13, color: 'var(--red)', background: 'none', border: 'none', cursor: 'pointer' }}>Clear cart</button>
              </div>

              {items.map(item => (
                <div key={item.CartItemID} style={{ display: 'flex', gap: 16, padding: '20px 0', borderBottom: '1px solid var(--border)' }}>
                  <div style={{ width: 90, height: 90, background: 'var(--cream)', borderRadius: 10, overflow: 'hidden', flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 28, border: '1px solid var(--border)' }}>
                    {item.ImageURL ? <img src={item.ImageURL} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }}/> : '📦'}
                  </div>
                  <div style={{ flex: 1 }}>
                    <Link to={`/product/${item.ProductID}`} style={{ fontSize: 15, fontWeight: 600, color: 'var(--ink)', display: 'block', marginBottom: 4, lineHeight: 1.4 }}>{item.ProductName || item.Name}</Link>
                    {item.Brand && <div style={{ fontSize: 12, color: 'var(--muted)', marginBottom: 8 }}>{item.Brand}</div>}
                    <div style={{ display: 'flex', alignItems: 'center', gap: 16, flexWrap: 'wrap' }}>
                      <div style={{ display: 'flex', alignItems: 'center', border: '1px solid var(--border2)', borderRadius: 8, overflow: 'hidden' }}>
                        <button onClick={() => updateItem(item.CartItemID, item.Quantity - 1)} style={{ width: 32, height: 32, background: 'var(--cream)', border: 'none', cursor: 'pointer', fontSize: 16, fontWeight: 700 }}>−</button>
                        <span style={{ width: 36, textAlign: 'center', fontSize: 14, fontWeight: 600 }}>{item.Quantity}</span>
                        <button onClick={() => updateItem(item.CartItemID, item.Quantity + 1)} style={{ width: 32, height: 32, background: 'var(--cream)', border: 'none', cursor: 'pointer', fontSize: 16, fontWeight: 700 }}>+</button>
                      </div>
                      <button onClick={() => removeItem(item.CartItemID)} style={{ fontSize: 12, color: 'var(--red)', background: 'none', border: 'none', cursor: 'pointer' }}>Remove</button>
                    </div>
                  </div>
                  <div style={{ textAlign: 'right', flexShrink: 0 }}>
                    <div style={{ fontSize: 17, fontWeight: 700 }}>₹{((item.Price || item.UnitPrice) * item.Quantity)?.toLocaleString('en-IN')}</div>
                    {item.Quantity > 1 && <div style={{ fontSize: 12, color: 'var(--muted)' }}>₹{(item.Price || item.UnitPrice)?.toLocaleString('en-IN')} each</div>}
                  </div>
                </div>
              ))}
            </div>

            {/* Summary */}
            <div style={{ background: 'var(--white)', border: '1px solid var(--border)', borderRadius: 16, padding: 24, position: 'sticky', top: 100 }}>
              <h3 style={{ fontSize: 18, fontWeight: 700, marginBottom: 20 }}>Order Summary</h3>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 12, marginBottom: 20 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 14 }}>
                  <span style={{ color: 'var(--sub)' }}>Subtotal</span>
                  <span style={{ fontWeight: 600 }}>₹{(summary.subtotal || 0)?.toLocaleString('en-IN')}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 14 }}>
                  <span style={{ color: 'var(--sub)' }}>Shipping</span>
                  <span style={{ color: (summary.subtotal || 0) >= 499 ? 'var(--green)' : 'var(--ink)', fontWeight: 600 }}>
                    {(summary.subtotal || 0) >= 499 ? 'FREE' : '₹49'}
                  </span>
                </div>
                {discountAmt > 0 && (
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 14 }}>
                    <span style={{ color: 'var(--green)' }}>Coupon discount</span>
                    <span style={{ color: 'var(--green)', fontWeight: 600 }}>−₹{discountAmt.toLocaleString('en-IN')}</span>
                  </div>
                )}
                <div style={{ borderTop: '1px solid var(--border)', paddingTop: 12, display: 'flex', justifyContent: 'space-between', fontSize: 17, fontWeight: 700 }}>
                  <span>Total</span>
                  <span>₹{finalTotal.toLocaleString('en-IN')}</span>
                </div>
              </div>

              {/* Coupon */}
              <div style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
                <input value={coupon} onChange={e => setCoupon(e.target.value.toUpperCase())} className="input" placeholder="Coupon code" style={{ flex: 1, fontSize: 13 }}/>
                <button onClick={handleCoupon} disabled={validating} className="btn btn-outline btn-sm" style={{ whiteSpace: 'nowrap' }}>
                  {validating ? '…' : 'Apply'}
                </button>
              </div>

              <button onClick={() => navigate('/checkout', { state: { discount } })} className="btn btn-gold btn-lg" style={{ width: '100%', justifyContent: 'center' }}>
                Proceed to Checkout →
              </button>
              <Link to="/shop" style={{ display: 'block', textAlign: 'center', marginTop: 12, fontSize: 13, color: 'var(--muted)' }}>← Continue Shopping</Link>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
export default CartPage;
