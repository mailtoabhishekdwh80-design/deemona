// ============================================================
//  DEEMONA — Complete Backend Server  (server.js)
//  Ready-to-run: node server.js  |  Dev: npm run dev
//  Docs: http://localhost:3000/api-docs
//  Health: http://localhost:3000/api/health
// ============================================================
'use strict';
require('dotenv').config();

const express  = require('express');
const cors     = require('cors');
const helmet   = require('helmet');
const morgan   = require('morgan');
const path     = require('path');

// ── Route modules ──────────────────────────────────────────
const authRoutes      = require('./routes/auth');       // upgraded: refresh tokens, 2FA, admin auth
const customerRoutes  = require('./routes/customers');
const catalogueRoutes = require('./routes/catalogue');
const commerceRoutes  = require('./routes/commerce');
const extrasRoutes    = require('./routes/extras');
const missingRoutes   = require('./routes/missing');
const paymentRoutes   = require('./routes/payments');   // full gateway: initiate, verify, webhook, refund
const { limiters }    = require('./middleware');

// ── Services ───────────────────────────────────────────────
const jobs = require('./services/jobs');

const app  = express();
const PORT = process.env.PORT || 3000;

// ── Trust proxy (required when behind Nginx / load balancer)
// Ensures req.ip is real client IP, not the proxy IP
app.set('trust proxy', 1);

// ── Webhook raw body (MUST be before express.json) ────────
// Razorpay & Stripe need the raw Buffer to verify signatures
app.use('/api/payments/webhook', express.raw({ type: 'application/json' }));

// ── Security & parsing ─────────────────────────────────────
app.use(helmet({
  contentSecurityPolicy: false,
  crossOriginEmbedderPolicy: false,
}));
// CORS: accept comma-separated origins from env (dev + production frontend)
const allowedOrigins = (process.env.CORS_ORIGIN || '*').split(',').map(o => o.trim());
app.use(cors({
  origin: (origin, cb) => {
    if (!origin || allowedOrigins.includes('*') || allowedOrigins.includes(origin)) {
      cb(null, true);
    } else {
      cb(new Error('Not allowed by CORS'));
    }
  },
  methods:        ['GET','POST','PUT','PATCH','DELETE','OPTIONS'],
  allowedHeaders: ['Content-Type','Authorization','X-Referral-Code'],
  credentials:    true,
}));
app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true, limit: '2mb' }));
app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));

// ── Static files (frontend) ────────────────────────────────
app.use(express.static(path.join(__dirname, 'public')));

// ── Rate limiting ──────────────────────────────────────────
app.use('/api/', limiters.api);
app.use('/api/auth/', limiters.auth);
app.use('/api/search', limiters.search);
// Write limiter — applied to all mutating operations
['POST','PUT','PATCH','DELETE'].forEach(method =>
  app.use((req, res, next) => req.method === method ? limiters.write(req, res, next) : next())
);

// ── Health & info endpoints ────────────────────────────────
app.get('/api/health', async (req, res) => {
  let dbStatus = 'unknown';
  try {
    const { getPool } = require('./config/db');
    const db = await getPool();
    await db.request().query('SELECT 1');
    dbStatus = 'connected';
  } catch { dbStatus = 'offline'; }
  res.status(dbStatus === 'connected' ? 200 : 503).json({
    status:    dbStatus === 'connected' ? 'ok' : 'degraded',
    service:   'Deemona E-Commerce API',
    version:   '1.0.0',
    timestamp: new Date().toISOString(),
    database:  dbStatus,
    env:       process.env.NODE_ENV || 'development',
  });
});

app.get('/api/version', (req, res) => {
  res.json({ name: 'Deemona API', version: '1.0.0', nodeVersion: process.version });
});

// ── Mount all routers ──────────────────────────────────────
app.use('/api/auth',      authRoutes);
app.use('/api/customers', customerRoutes);
app.use('/api',           catalogueRoutes);  // /api/categories, /api/products, /api/inventory
app.use('/api',           commerceRoutes);   // /api/cart, /api/orders, /api/shipping (basic payment CRUD kept)
app.use('/api/payments',  paymentRoutes);    // /api/payments/initiate, /verify, /webhook, /:id/refund, /admin/stats
app.use('/api',           extrasRoutes);     // /api/reviews, /api/wishlist, /api/discounts, /api/affiliates, /api/suppliers, /api/search, /api/admin
app.use('/api',           missingRoutes);    // /api/addresses, /api/admin/reports, /api/orders/:id/invoice, etc.

// ── 404 for unknown API routes ─────────────────────────────
app.use('/api/*', (req, res) => {
  res.status(404).json({ success: false, error: `API endpoint not found: ${req.method} ${req.path}` });
});

// ── Serve frontend SPA for all other routes ────────────────
app.get('*', (req, res) => {
  const indexPath = path.join(__dirname, 'public', 'index.html');
  res.sendFile(indexPath, err => {
    if (err) res.status(200).send('<h1>Deemona API is running.</h1><p>Visit <a href="/api/health">/api/health</a></p>');
  });
});

// ── Global error handler ───────────────────────────────────
app.use((err, req, res, _next) => {
  const isDev = process.env.NODE_ENV !== 'production';
  console.error(`❌  [${new Date().toISOString()}] ${req.method} ${req.path}`, err.message);
  if (isDev) console.error(err.stack);

  // Business logic errors
  if (err.message?.includes('not found'))             return res.status(404).json({ success:false, error: err.message });
  if (err.message?.includes('stock'))                 return res.status(400).json({ success:false, error: err.message });
  if (err.message?.includes('Coupon'))                return res.status(400).json({ success:false, error: err.message });
  if (err.message?.includes('Cannot transition'))     return res.status(400).json({ success:false, error: err.message });
  if (err.message?.includes('SKU'))                   return res.status(409).json({ success:false, error: err.message });

  const message = isDev ? err.message : 'An unexpected error occurred. Please try again.';
  res.status(500).json({ success: false, error: message });
});

// ── Start server ───────────────────────────────────────────
const server = app.listen(PORT, async () => {
  const { getPool } = require('./config/db');
  console.log(`
  ╔══════════════════════════════════════════════╗
  ║   DEEMONA E-COMMERCE API  v1.0.0             ║
  ║   Discover · Dream · Deliver                 ║
  ╠══════════════════════════════════════════════╣
  ║   Base URL : http://localhost:${String(PORT).padEnd(4)}           ║
  ║   Health   : http://localhost:${String(PORT).padEnd(4)}/api/health ║
  ║   Docs     : http://localhost:${String(PORT).padEnd(4)}/api-docs   ║
  ║   Env      : ${String(process.env.NODE_ENV||'development').padEnd(29)} ║
  ╚══════════════════════════════════════════════╝`);
  try {
    await getPool();
    jobs.start();   // start cron jobs only after DB is confirmed connected
  }
  catch(e) { console.warn('\n⚠  Database offline — server started in API-only mode:', e.message); }
});

server.on('error', err => {
  if (err.code === 'EADDRINUSE') {
    console.error(`❌  Port ${PORT} is already in use. Change PORT in .env`);
    process.exit(1);
  }
  throw err;
});

// Graceful shutdown
const shutdown = async (signal) => {
  console.log(`\n${signal} received — shutting down gracefully...`);
  jobs.stop();    // stop cron jobs first
  server.close(() => { console.log('HTTP server closed.'); process.exit(0); });
  setTimeout(() => { console.error('Forced shutdown after timeout.'); process.exit(1); }, 10000);
};
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT',  () => shutdown('SIGINT'));

module.exports = app;
